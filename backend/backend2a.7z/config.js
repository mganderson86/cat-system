module.exports = {
    
    user: 'test',
    password: '1234pass!',
    //server: 'HBS-310s-IT-XXX.times.uh.edu', 
    //server: 'HBS-353U-DM-LVI.times.uh.edu', 
	server: 'cat-dev.times.uh.edu', 
    database: 'CAT2A',
    options: {
        "enableArithAbort": true,
        encrypt: true
    }
    
}
