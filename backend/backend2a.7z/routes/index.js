// var express = require('express');
// var router = express.Router();
// var db = require("../db");

// /* GET home page. */
// router.get('/', function(req, res, next) {
//   res.render('index', { title: 'Express' });
//   db.query("SELECT * FROM Student_information", [], function(results, fields) {
//     console.log(results);
//   })
  
// });

// module.exports = router;
